
```bash

helm install member-release . -n helm01
helm install member-release . -n helm01 --create-namespace
helm upgrade my-release .
helm upgrade my-release . --set replicaCount=5
helm history my-release
helm rollback my-release 1
helm uninstall my-release

```